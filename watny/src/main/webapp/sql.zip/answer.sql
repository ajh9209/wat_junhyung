
CREATE TABLE `answer`(			-- ���� Tb
	`a_qno`		INT				not null,
	`a_answer`	VARCHAR(50)		not null
);

Insert into 
answer(a_qno, a_answer)
values(1, '�質��');

select * from answer;