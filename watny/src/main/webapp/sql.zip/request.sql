
CREATE TABLE request(			-- �Ƿ� Tb
	rq_no			INT					not null 		primary key,
	rq_id			VARCHAR(15)			not null,
	rq_title 		VARCHAR(100)		not null,
	rq_comtent		VARCHAR(5000)		not null,
	rq_templete		VARCHAR(50)			null,
	rq_newdate		DATETIME			not null,
	rq_enddate		DATETIME			null,
	rq_state		INT					not null
);
