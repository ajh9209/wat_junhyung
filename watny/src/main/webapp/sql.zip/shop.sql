
CREATE TABLE shop(			-- ��ٱ��� Tb
	shop_no       INT		      not null 		PRIMARY KEY,
	shop_id       VARCHAR(15)     not null,
	shop_sellno   INT		      not null,
	shop_date     VARCHAR(20)     not null
);